const UseStateArray = () => {
  return <h2>useState array example</h2>;
};

export default UseStateArray;
