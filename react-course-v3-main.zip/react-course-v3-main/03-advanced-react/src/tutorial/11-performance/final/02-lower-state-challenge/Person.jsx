const Person = ({ name }) => {
  return (
    <div>
      <h4>{name}</h4>
    </div>
  );
};
export default Person;
